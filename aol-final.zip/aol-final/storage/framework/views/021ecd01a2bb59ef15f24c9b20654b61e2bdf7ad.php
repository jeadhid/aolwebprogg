<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center mb-4">
        <h2 class="fw-bold">Edit Disease: <?php echo e($disease->name); ?></h2>
        <p>
            <span class="badge bg-info text-dark fs-5 py-2 px-3">Category:
                <select class="form-select d-inline w-auto" name="category_id" form="editDiseaseForm">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" 
                            <?php echo e($disease->category_id == $item->id ? 'selected' : ''); ?>>
                            <?php echo e($item->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </span>
        </p>
    </div>

    <div class="row">
        <div class="col-md-5">
            <label for="diseaseImage" class="form-label fw-bold">Disease Image</label>
            <input type="file" class="form-control" id="diseaseImage" name="image" form="editDiseaseForm">
            <img src="<?php echo e($disease->image ? asset('storage/' . $disease->image) : 'https://via.placeholder.com/600x400?text=Disease+Image'); ?>"
                 alt="Disease Image"
                 class="img-fluid rounded mt-3"
                 style="box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);">
        </div>

        <div class="col-md-7">
            <form id="editDiseaseForm" action="<?php echo e(route('disease.update', ['id' => $disease->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="name" class="form-label fw-bold">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $disease->name)); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="overview" class="form-label fw-bold">Overview</label>
                    <textarea class="form-control" id="overview" name="overview" rows="4" required><?php echo e(old('overview', $disease->description)); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="symptoms" class="form-label fw-bold">Symptoms</label>
                    <textarea class="form-control" id="symptoms" name="symptoms" rows="3" required><?php echo e(old('symptoms', $disease->symptoms)); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="causes" class="form-label fw-bold">Causes</label>
                    <textarea class="form-control" id="causes" name="causes" rows="3" required><?php echo e(old('causes', $disease->causes)); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="treatment" class="form-label fw-bold">Treatment</label>
                    <textarea class="form-control" id="treatment" name="treatment" rows="3" required><?php echo e(old('treatment', $disease->treatment)); ?></textarea>
                </div>
                <div class="text-center mt-5">
                    <a href="<?php echo e(route('disease')); ?>" class="btn btn-danger btn-lg"><i class="fas fa-times"></i> Cancel</a>
                    <button type="submit" class="btn btn-success btn-lg me-2"><i class="fas fa-save"></i> Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jeson Adhi Dharma\Documents\Semester 5\aol webprog\aol-final\resources\views/edit.blade.php ENDPATH**/ ?>