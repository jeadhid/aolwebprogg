<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Page Header -->
    <div class="text-center mb-4">
        <h2 class="fw-bold">Disease Categories</h2>
        <p class="text-muted">Explore diseases by category to understand their types and impacts.</p>
    </div>

    <!-- Categories Grid -->
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card h-100">
                    <!-- Styled Image -->
                    <img src="<?php echo e(asset('storage/categories/'.$item->photo)); ?>"
                         class="card-img-top"
                         alt="<?php echo e($item->name); ?>"
                         style="border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); max-height: 200px; object-fit: cover;">

                    <!-- Card Content -->
                    <div class="card-body text-center">
                        <h5 class="card-title fw-bold"><?php echo e($item->name); ?></h5>
                        <p class="card-text text-muted">
                            <?php echo e($item->description); ?>

                        </p>
                        <a href="<?php echo e(route('disease', ['category_id' => $item->id])); ?>" class="btn btn-primary"><i class="fas fa-arrow-right"></i> View Diseases</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jeson Adhi Dharma\Documents\Semester 5\aol webprog\aol-final\resources\views/categories.blade.php ENDPATH**/ ?>